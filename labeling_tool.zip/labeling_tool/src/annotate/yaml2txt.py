#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# Usage: python yaml2txt.py --input annotate标注工具生成的yaml文件位置

import os
import yaml
import argparse
import transforms3d as tfs

LABEL_DICT={
    "person":"Pedestrian",
    "car":"Car",
    "bicycle":"Cyclist"
}

YAML_FILE="data/yaml/annotate3.yaml"

ROOT='data/dataset'
LABEL_FOLDER=ROOT+'/training/label'
DATASET_FOLDER=ROOT+'/ImageSets'

# 读取yaml文件，保存到data中并以字典形式返回
def get_yaml_data(yaml_file):
    file = open(yaml_file, 'r', encoding="utf-8")
    file_data = file.read()
    file.close()
    # ppyaml版本不兼容，使用safe_load()替换load()函数
    # data = yaml.load(file_data)
    data = yaml.safe_load(file_data)
    return data

# 四元数转固定轴欧拉角(默认sxyz)，并返回最后一位z轴的旋转角yaw
def quat2euler_z(w,x,y,z):
    angles=tfs.euler.quat2euler([w,x,y,z])
    return angles[2]

if __name__=='__main__':
    # 导入argparse包，按ArgumentParser类生成parser对象
    parser = argparse.ArgumentParser('Please input the annotation file path you want to transfer using --input=""')
    # 调用add_argument()函数添加命令行参数
    parser.add_argument(
        '-i',
        '--input',
        type=str,
        help='Path to the file you want to transfer.')
    
    # 通过parse_args()方法解析命令行参数，将每个参数转化为适当的数据类型，并将其结构化后存放到对象args中
    args = parser.parse_args()

    # 所需转化yaml文件位置更新
    if args.input is None:
        raise FileNotFoundError("Please input the file's path to start!")
    else:
        # args.input = os.Path(args.input)
        #print(args.input)
        YAML_FILE = args.input
        print("YAML_FILE =", YAML_FILE)

    # 如不存在，创建新的dataset和label文件夹
    if not os.path.exists(LABEL_FOLDER):
        os.makedirs(LABEL_FOLDER)
    if not os.path.exists(DATASET_FOLDER):
        os.makedirs(DATASET_FOLDER)

    # 依次读取yaml文件字典信息，并写入指定位置文件中
    d=get_yaml_data(yaml_file=YAML_FILE)
    labels=d['labels']
    tags=d['tags']
    tracks=d['tracks']

    for id_tracks in tracks:
        track=id_tracks['track']
        for t in track:
            # label.txt文件名(以时间戳命名)
            name=str(t['header']['stamp']['secs'])+'_'+ '%09d' % t['header']['stamp']['nsecs']
            # default label = ["person", "car","bicycle"]
            label=t['label']
            # B-Box中心点位置，四元数，长宽高，旋转欧拉角yaw
            x=t['translation']['x']
            y=t['translation']['y']
            z=t['translation']['z']
            qw=t['rotation']['w']
            qx=t['rotation']['x']
            qy=t['rotation']['y']
            qz=t['rotation']['z']
            l=t['box']['length']
            w=t['box']['width']
            h=t['box']['height']
            r=quat2euler_z(qw,qx,qy,qz)

            # 转化后的txt标签格式label_line：1(类别,str)，2(是否截断,float)，3(是否遮挡,int)，4(物体观察角度,弧度)，5～8(2D边框大小,xmin/ymin/xmax/ymax)，
            # 9~11(3D B-Box尺寸，L/W/H)，12～14(3D B-Box中心点，x/y/z),15(3D B-Box方向,弧度)
            label_line=LABEL_DICT[label]+' 0.00 0 0 642.24 178.50 680.14 208.68'+' '+str(h)+' '+str(w)+' '+str(l)+' '+str(x)+' '+str(y)+' '+str(z)+' '+str(r)+'\n'
            print('line: {}'.format(label_line))

            # 获取label.txt文件路径，并将转化过后的label_line信息写入
            label_file=os.path.join(LABEL_FOLDER,name+'.txt')
            with open(label_file,'a+') as lf:
                lf.write(label_line)
            # 将转化后的标签名name依次写入test.txt文件中，其与所有转化的label.txt文件相对应
            test_all_file=os.path.join(DATASET_FOLDER,'test.txt')
            with open(test_all_file,'a+') as tf:
                tf.write(name+'\n')
